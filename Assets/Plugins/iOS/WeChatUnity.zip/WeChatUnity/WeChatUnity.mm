// WeChatUnity.mm

#import <Foundation/Foundation.h>
#import "WXApiManager.h"

#define UNITY_CS_API extern "C"

extern "C" void UnitySendMessage(const char* obj, const char* method, const char* msg);

static NSString *mWXAppid = nil;

// 将c字符串const char* 转为 oc字符串NSString
static inline NSString * str_c2ns(const char*s)
{
    if (s)
        return [NSString stringWithUTF8String: s];
    else
        return [NSString stringWithUTF8String: ""];
}

// dic转jsonstr
static NSString * dictToJson(NSDictionary *dict)
{
    if (!dict || ![dict isKindOfClass:[NSDictionary class]]) {
        NSLog(@"PluginUtils: dictToJson - 输入参数无效");
        return nil;
    }
    
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    
    if (error) {
        NSLog(@"PluginUtils: dictToJson - JSON序列化失败: %@", error.localizedDescription);
        return nil;
    }
    
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    if (!jsonString) {
        NSLog(@"PluginUtils: dictToJson - 无法创建JSON字符串");
        return nil;
    }
    
    return jsonString;
}

// 发送微信登录回调消息
static void sendWechatLoginCallback(BOOL isSuccess, NSString *code)
{
    NSString *successStr = isSuccess ? @"true" : @"false";
    NSDictionary* receiveMap = @{@"isSuccess": successStr, @"code": code ?: @""};
    NSString* jsonStr = dictToJson(receiveMap);
    const char *p1 = [jsonStr UTF8String];
    UnitySendMessage("IosCallBack", "WechatLoginCallback", p1);
}

// 初始化
UNITY_CS_API void initWeChat(const char* appId, const char* universalLink)
{
    NSString *appIdStr = str_c2ns(appId);
    NSString *ul = str_c2ns(universalLink);
    NSLog(@"[WeChatUnity] initWeChat appId=%@, universalLink=%@", appIdStr, ul);
    mWXAppid = appIdStr;
    [WXApi registerApp:mWXAppid universalLink:ul];
}


// 登录
UNITY_CS_API void authLogin(int platformType)
{
    NSLog(@"[WeChatUnity] authLogin appId=%d", platformType);
    if (![WXApi isWXAppInstalled]){
        NSLog(@"[WeChatUnity] authLogin isWXAppInstalled: false");
        // [self OnCompleteFailCall:@"wechat not installed"];
        sendWechatLoginCallback(false, @"WXAppNotInstalled");
        return;
    }

    SendAuthReq *req = [SendAuthReq new];
    req.scope = @"snsapi_userinfo";
    req.state = @"u3d_wechat_auth";
    [WXApi sendReq:req completion:^(bool success){
        NSLog(@"[WeChatUnity] authLogin send auth req: %@", success ? @"success" : @"fail");
        if (success) {
            NSLog(@"wechat login callback gives success 1111");
        } else {
            NSLog(@"wechat login callback gives failure");
            sendWechatLoginCallback(false, @"wechat login callback gives failure");
        }
    }];

}


