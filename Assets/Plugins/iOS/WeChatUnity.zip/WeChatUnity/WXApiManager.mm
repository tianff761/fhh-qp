#import "WXApiManager.h"

@implementation WXApiManager

extern "C" void UnitySendMessage(const char* obj, const char* method, const char* msg);


// dic转jsonstr
static NSString * dictToJson(NSDictionary *dict)
{
    if (!dict || ![dict isKindOfClass:[NSDictionary class]]) {
        NSLog(@"PluginUtils: dictToJson - 输入参数无效");
        return nil;
    }
    
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    
    if (error) {
        NSLog(@"PluginUtils: dictToJson - JSON序列化失败: %@", error.localizedDescription);
        return nil;
    }
    
    NSString *jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    
    if (!jsonString) {
        NSLog(@"PluginUtils: dictToJson - 无法创建JSON字符串");
        return nil;
    }
    
    return jsonString;
}

// 发送微信登录回调消息
static void sendWechatLoginCallback(BOOL isSuccess, NSString *code)
{
    NSString *successStr = isSuccess ? @"true" : @"false";
    NSDictionary* receiveMap = @{@"isSuccess": successStr, @"code": code ?: @""};
    NSString* jsonStr = dictToJson(receiveMap);
    const char *p1 = [jsonStr UTF8String];
    UnitySendMessage("IosCallBack", "WechatLoginCallback", p1);
}

// 单例
+(instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static WXApiManager *instance;
    dispatch_once(&onceToken, ^{
        instance = [[WXApiManager alloc] init];
    });
    return instance;
}

- (void)onResp:(BaseResp *)resp {
    NSLog(@"llllllll on resp");
	// TODO 微信回调，调用微信SDK的sendReq，会回调此方法，登录、分享等都是回调到这里
    if ([resp isKindOfClass:[SendAuthResp class]]) {
        SendAuthResp *authResp = (SendAuthResp *)resp;
         [self managerDidRecvAuthResponse:authResp];
    }
}

- (void)onReq:(BaseReq *)req {
	// TODO 微信回调，从微信端主动发送过来的请求
}

- (void)managerDidRecvAuthResponse:(SendAuthResp *)response {
    int errorCode = response.errCode;
    if (errorCode) {
        [self OnCompleteCall:[NSString stringWithFormat:@"wechat error: %d", errorCode]];
    } else {
        [self OnCompleteCall:response.code];
    }
}

-(void)OnCompleteCall:(NSString*)msg
{
    NSDictionary* receiveMap = @{@"isSuccess":@"true",@"code":msg};
    NSString* jsonStr = dictToJson(receiveMap);
    const char *p1 = [jsonStr UTF8String];
    UnitySendMessage("IosCallBack", "WechatLoginCallback", p1);
}


@end
